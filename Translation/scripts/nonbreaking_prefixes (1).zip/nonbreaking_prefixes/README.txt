The language suffix can be found here:

http://www.loc.gov/standards/iso639-2/php/code_list.php

This code includes data from Daniel Naber's Language Tools (czech abbreviations).
This code includes data from czech wiktionary (also czech abbreviations).


